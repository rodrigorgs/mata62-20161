package ufba.app;

public enum TipoDocumento {
	HTML,
	MARKDOWN
}
