package rental;

public class Main {

	// example
	public static void main(String[] args) {
		Customer customer = new Customer("Fred");
		
		Movie hulk = new Movie("The Hulk", Movie.CHILDREN);
		Movie ironMan = new Movie("Iron Man 4", Movie.NEW_RELEASE);
		Movie spiderman = new Movie("Spiderman", Movie.REGULAR);
		
        customer.addRental(new Rental(hulk, 2));
        customer.addRental(new Rental(ironMan, 1));
        customer.addRental(new Rental(spiderman, 3));
        
        System.out.println(customer.statement());
	}

}
