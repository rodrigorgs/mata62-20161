package forca;

import java.util.List;

public class Partida {
	private Pontuacao pontuacao;
	private Palavra palavra;
	private Jogador vencedor = null;
	private List<Jogador> jogadores;
	private int indiceJogadorAtual = -1;
	
	public Partida(List<Jogador> jogadores, Palavra palavra) {
		this.pontuacao = new Pontuacao();
		this.palavra = palavra;
		this.jogadores = jogadores;
	}
	
	public Jogador proximoJogador() {
		indiceJogadorAtual = (indiceJogadorAtual + 1) % jogadores.size();
		return getJogadorAtual();
	}
	
	public Jogador getJogadorAtual() {
		return jogadores.get(indiceJogadorAtual);
	}
	
	public Jogador getVencedor() {
		return vencedor;
	}

	public boolean finalizada() {
		return getVencedor() != null;
	}
	
	public int numErros() {
		return pontuacao.getErros().size();
	}
	
	public int numAcertos() {
		return pontuacao.getAcertos().size();
	}

	/**
	 * @return true se a jogada foi v�lida; false caso contr�rio.
	 */
	public boolean joga(Letra letra) {
		if (pontuacao.getErros().contains(letra) || pontuacao.getAcertos().contains(letra)) {
			return false;
		} else {
			if (palavra.possuiLetra(letra)) {
				pontuacao.adicionaAcerto(letra);
				if (palavra.numLetrasDiferentes() == numAcertos()) {
					vencedor = getJogadorAtual();
				}
			} else {
				pontuacao.adicionaErro(letra);
			}
			return true;
		}
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		
		sb.append("Palavra: ");
		sb.append(palavra.paraString(pontuacao.getAcertos()));
		
		sb.append("Erros: ");
		for (Letra letra : pontuacao.getErros()) {
			sb.append(letra.toString());
			sb.append(' ');
		}
		
		return sb.toString();
	}
	
}
