package forca;

public class Jogador {
	private String nome;
	
	public Jogador(String nome) {
		super();
		this.nome = nome;
	}

	@Override
	public String toString() {
		return this.nome;
	}
}
