package forca;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Dicionario {
	private List<Palavra> palavras;
	private Random random = new Random(System.currentTimeMillis());
	
	public Dicionario() {
		palavras = new ArrayList<Palavra>();
		palavras.add(new Palavra("scrum"));
		palavras.add(new Palavra("evolucionario"));
		palavras.add(new Palavra("cascata"));
		palavras.add(new Palavra("estereotipo"));
		palavras.add(new Palavra("backlog"));
	}
	
	public Palavra obtemPalavra() {
		int i = random.nextInt(palavras.size());
		return palavras.get(i);
	}
}
