package forca;

import java.util.HashSet;
import java.util.Set;

public class Palavra {
	private String nome;
	private String definicao;
	private Set<Letra> letras;
	
	public Palavra(String nome) {
		this.nome = nome;
		this.definicao = "";
		this.letras = new HashSet<Letra>();
		
		for (int i = 0; i < this.nome.length(); i++){
		    char c = this.nome.charAt(i);        
		    letras.add(new Letra(c));
		}
	}
	
	public int numLetrasDiferentes() {
		return letras.size();
	}
	public int tamanho() {
		return nome.length();
	}
	public boolean possuiLetra(Letra letra) {
		return letras.contains(letra);
	}

	public String paraString(Set<Letra> acertos) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < this.nome.length(); i++){
			Letra letra = new Letra(this.nome.charAt(i));
			if (acertos.contains(letra)) {
				sb.append(letra.toString());
			} else {
				sb.append('_');
			}
			sb.append(' ');
		}
		sb.append("\n");
		return sb.toString();
	}
	
	
}
