package forca;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Campeonato {
	private Collection<Partida> partidas;
	private Dicionario dicionario;
	private List<Jogador> jogadores;
	
	public Campeonato() {
		this.partidas = new ArrayList<Partida>();
		this.dicionario = new Dicionario();
		this.jogadores = new ArrayList<Jogador>();
		this.jogadores.add(new Jogador("Alfa"));
		this.jogadores.add(new Jogador("Beta"));
	}
	
	public int numVitorias(Jogador j) {
		// TODO
		return 0;
	}
	
	public Jogador[] vencedorCampeonato() {
		// TODO
		return new Jogador[0];
	}
	
	public boolean finalizado() {
		// TODO
		return false;
	}
	
	public Partida proximaPartida() {
		Partida partida = new Partida(this.jogadores, dicionario.obtemPalavra());
		partidas.add(partida);
		return partida;
	}
}
