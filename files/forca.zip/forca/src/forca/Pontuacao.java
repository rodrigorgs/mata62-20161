package forca;

import java.util.HashSet;
import java.util.Set;

public class Pontuacao {
	private Set<Letra> acertos;
	private Set<Letra> erros;
	
	public Pontuacao() {
		acertos = new HashSet<Letra>();
		erros = new HashSet<Letra>();
	}
	
	public boolean adicionaErro(Letra letra) {
		return erros.add(letra);
	}
	public boolean adicionaAcerto(Letra letra) {
		return acertos.add(letra);
	}
	public Set<Letra> getErros() {
		return erros;
	}
	public void setAcertos(Set<Letra> acertos) {
		this.acertos = acertos;
	}
	public Set<Letra> getAcertos() {
		return acertos;
	}
}
