package forca;

import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws IOException {
		Campeonato campeonato = new Campeonato();
		Scanner scanner = new Scanner(System.in);
		
		while (!campeonato.finalizado()) {
			Partida partida = campeonato.proximaPartida();
			while (!partida.finalizada()) {
				Jogador jogador = partida.proximoJogador();
				Letra letra;
				do {
					System.out.println("\n" + partida);
					System.out.println("" + jogador + ", escolha uma letra: ");
					char c = scanner.next().charAt(0);
					letra = new Letra(c);
				} while (!partida.joga(letra));
			}
			
			System.out.println("\n*********\nVencedor: " + partida.getVencedor() + "\n*********\n");
		}
		
		scanner.close();
	}
}
