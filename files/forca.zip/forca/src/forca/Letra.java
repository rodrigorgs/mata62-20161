package forca;

public class Letra {

	private char nome = ' ';

	public Letra(char nome) {
		super();
		this.nome = nome;
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Letra)) {
			return false;
		}
		return this.nome == ((Letra)other).nome;
	}

	@Override
	public int hashCode() {
		return this.nome;
	}

	@Override
	public String toString() {
		return "" + this.nome;
	}
}
